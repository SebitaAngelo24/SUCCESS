const personas = require("./personas.json");
console.log(personas)

console.log(personas);

module.exports = personas;