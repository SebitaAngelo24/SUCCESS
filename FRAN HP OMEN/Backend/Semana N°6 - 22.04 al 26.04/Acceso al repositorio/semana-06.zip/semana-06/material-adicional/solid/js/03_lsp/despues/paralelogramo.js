export default class Paralelogramo {
    base;
    altura;
    constructor(base, altura) {
        this.setBase(base);
        this.setAltura(altura);
    }
    getBase() {
        return this.base;
    }
    setBase(base) {
        this.base = base;
    }
    getAltura() {
        return this.altura;
    }
    setAltura(altura) {
        this.altura = altura;
    }
    calcularSuperficie() {
        return this.base * this.altura;
    }
}
