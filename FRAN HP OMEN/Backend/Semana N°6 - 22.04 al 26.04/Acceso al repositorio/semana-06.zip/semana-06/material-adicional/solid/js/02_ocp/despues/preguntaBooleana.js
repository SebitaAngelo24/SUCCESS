export default class PreguntaBooleana {
    constructor(texto) {
        this.texto = texto;
    }

    ImprimirDetallePregunta() {
        console.log("1. Si");
        console.log("2. No");
    }
}
