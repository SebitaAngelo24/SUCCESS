export default class PreguntaMultipleOpcion {
	constructor(texto, opciones) {
		this.texto = texto;
		this.opciones = opciones;
	}

	ImprimirDetallePregunta() {
		this.opciones.forEach((opcion, index) => {
			console.log(`${index + 1}. ${opcion}`);
		});
	}
}
