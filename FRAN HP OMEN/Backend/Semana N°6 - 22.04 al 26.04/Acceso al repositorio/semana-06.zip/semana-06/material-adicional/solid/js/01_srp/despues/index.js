import Logger from "./logger.js";

class ControladorGastos {
	constructor(presupuesto) {
		this.presupuesto = presupuesto;
		this.gastos = 0.0;
	}

	registrarGasto(gasto) {
		this.gastos += gasto;

		if (this.gastos > this.presupuesto) {
			this.logExcesoPresupuesto();
		}
	}

	logExcesoPresupuesto() {
		Logger.log("¡Se ha excedido el presupuesto!");
	}
}

const controladorGastos = new ControladorGastos(5000);
controladorGastos.registrarGasto(1000);
controladorGastos.registrarGasto(2000);
controladorGastos.registrarGasto(4000);
controladorGastos.registrarGasto(2000);
