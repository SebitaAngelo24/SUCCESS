import TiendaMercadoP from "./tiendaMercadoP.js";
import TiendaMercadoQ from "./tiendaMercadoQ.js";

// Tienda con pagos por MercadoP
const tiendaMercadoP = new TiendaMercadoP("Juan Perez");
tiendaMercadoP.comprar("heladera", 3);
tiendaMercadoP.comprar("cocina", 2);

// Tienda con pagos por MercadoQ
const tiendaMercadoQ = new TiendaMercadoQ("Maria Manzo");
tiendaMercadoQ.comprar("heladera", 3);
tiendaMercadoQ.comprar("cocina", 2);
