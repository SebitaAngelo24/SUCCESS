import Paralelogramo from "./paralelogramo.js";

export default class Cuadrado extends Paralelogramo {
    constructor(lado) {
        super(lado, lado);
    }

    getLado() {
        return this.getBase();
    }
}
