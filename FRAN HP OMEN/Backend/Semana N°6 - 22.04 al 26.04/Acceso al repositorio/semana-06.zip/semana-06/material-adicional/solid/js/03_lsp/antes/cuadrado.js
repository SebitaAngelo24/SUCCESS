import Rectangulo from "./rectangulo.js";

export default class Cuadrado extends Rectangulo {
    setBase(base) {
        super.setBase(base);
        super.setAltura(base);
    }
    setAltura(altura) {
        super.setBase(altura);
        super.setAltura(altura);
    }
}
