import MercadoP from "./mercadoP.js";

export default class ProcesadorPagoMercadoP {
    constructor(usuario) {
        this.mercadoP = new MercadoP(usuario);
    }

    pagar(montoPesos) {
        this.mercadoP.realizarPago(montoPesos * 100);
    }
}
