export default class Logger {
	static log(mensaje) {
		console.log(mensaje);
	}
}
