export default class PreguntaRango {
    constructor(texto) {
        this.texto = texto;
    }

    ImprimirDetallePregunta() {
        console.log("Desde: ___________________");
        console.log("Hasta: ___________________");
    }
}
