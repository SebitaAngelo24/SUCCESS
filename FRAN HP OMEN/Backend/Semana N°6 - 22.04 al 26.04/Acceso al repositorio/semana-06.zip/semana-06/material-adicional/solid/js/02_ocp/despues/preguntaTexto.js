export default class PreguntaTexto {
    constructor(texto) {
        this.texto = texto;
    }

    ImprimirDetallePregunta() {
        console.log("Respuesta: ____________________");
    }
}
