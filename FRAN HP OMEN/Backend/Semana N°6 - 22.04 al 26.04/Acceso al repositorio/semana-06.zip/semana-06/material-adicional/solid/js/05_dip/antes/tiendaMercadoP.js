import MercadoP from "./mercadoP.js";

export default class Tienda {
    constructor(usuario) {
        this.mercadoP = new MercadoP(usuario);
        this.precios = { heladera: 140000, cocina: 90000 };
    }

    comprar(producto, cantidad) {
        this.mercadoP.realizarPago(
            this.aCentavos(this.precios[producto]) * cantidad
        );
    }

    aCentavos(monto) {
        return monto * 100;
    }
}
