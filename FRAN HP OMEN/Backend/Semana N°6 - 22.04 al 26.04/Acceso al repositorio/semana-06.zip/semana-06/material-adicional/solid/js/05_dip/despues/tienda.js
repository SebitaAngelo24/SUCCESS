export default class Tienda {
    constructor(procesadorPago) {
        this.procesadorPago = procesadorPago;
        this.precios = { heladera: 140000, cocina: 90000 };
    }

    comprar(producto, cantidad) {
        this.procesadorPago.pagar(this.precios[producto] * cantidad);
    }
}
