import Paralelogramo from "./paralelogramo.js";

export default class Rectangulo extends Paralelogramo {
    constructor(base, altura) {
        super(base, altura);
    }
}
