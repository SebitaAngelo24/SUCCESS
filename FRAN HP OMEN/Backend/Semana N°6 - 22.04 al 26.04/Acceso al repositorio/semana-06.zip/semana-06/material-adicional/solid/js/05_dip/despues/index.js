import Tienda from "./tienda.js";
import ProcesadorPagoMercadoP from "./procesadorPagoMercadoP.js";
import ProcesadorPagoMercadoQ from "./procesadorPagoMercadoQ.js";

let procesadorPago = new ProcesadorPagoMercadoP("Juan Perez");
let tienda = new Tienda(procesadorPago);
tienda.comprar("heladera", 3);
tienda.comprar("cocina", 2);

// Para cambiar de procesador solamente le pasamos otro procesador a la tienda
procesadorPago = new ProcesadorPagoMercadoQ("Maria Manzo");
tienda = new Tienda(procesadorPago);
tienda.comprar("heladera", 3);
tienda.comprar("cocina", 2);
