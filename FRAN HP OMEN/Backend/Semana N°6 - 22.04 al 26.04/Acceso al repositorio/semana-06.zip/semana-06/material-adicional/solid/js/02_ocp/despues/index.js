import PreguntaBooleana from "./preguntaBooleana.js";
import PreguntaMultipleOpcion from "./preguntaMultipleOpcion.js";
import PreguntaTexto from "./preguntaTexto.js";
import PreguntaRango from "./preguntaRango.js";

function imprimirCuestionario(preguntas) {
    preguntas.forEach((pregunta) => {
        console.log(pregunta.texto);
        pregunta.ImprimirDetallePregunta();
        console.log("");
    });
}

const preguntas = [
    new PreguntaBooleana("¿Es alumno regular?"),
    new PreguntaMultipleOpcion("¿Cuál es su lenguaje preferido?", [
        "C#",
        "SQL",
        "Javascript",
        "Python",
    ]),
    new PreguntaTexto(
        "Mencione la característica preferida del lenguaje seleccionado:"
    ),
    new PreguntaRango(
        "Lapso de tiempo en el que trabajó en su lenguaje preferido."
    ),
];

imprimirCuestionario(preguntas);
