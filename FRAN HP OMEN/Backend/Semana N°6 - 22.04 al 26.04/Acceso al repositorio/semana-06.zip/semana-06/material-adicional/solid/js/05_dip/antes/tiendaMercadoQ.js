import MercadoQ from "./mercadoQ.js";

export default class Tienda {
    constructor(usuario) {
        this.mercadoQ = new MercadoQ();
        this.usuario = usuario;
        this.precios = { heladera: 140000, cocina: 90000 };
    }

    comprar(producto, cantidad) {
        this.mercadoQ.realizarPago(
            this.usuario,
            this.precios[producto] * cantidad
        );
    }
}
