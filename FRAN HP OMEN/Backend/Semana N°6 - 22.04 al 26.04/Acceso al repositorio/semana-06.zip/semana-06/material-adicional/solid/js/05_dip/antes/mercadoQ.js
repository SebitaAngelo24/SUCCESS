export default class MercadoQ {
	realizarPago(usuario, montoPesos) {
		console.log(
			`${usuario} realizó el pago de $${montoPesos} con MercadoQ`
		);
	}
}
