import MercadoQ from "./mercadoQ.js";

export default class ProcesadorPagoMercadoQ {
    constructor(usuario) {
        this.mercadoQ = new MercadoQ();
        this.usuario = usuario;
    }

    pagar(montoPesos) {
        this.mercadoQ.realizarPago(this.usuario, montoPesos);
    }
}
