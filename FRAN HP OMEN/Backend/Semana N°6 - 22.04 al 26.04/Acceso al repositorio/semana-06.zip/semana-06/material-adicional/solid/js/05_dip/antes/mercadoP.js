export default class MercadoP {
    constructor(usuario) {
        this.usuario = usuario;
    }

    realizarPago(montoCentavos) {
        console.log(
            `${this.usuario} realizó el pago de $${
                montoCentavos / 100
            } con MercadoP`
        );
    }
}
