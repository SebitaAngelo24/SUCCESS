function imprimirCuestionario(preguntas) {
	preguntas.forEach((pregunta) => {
		console.log(pregunta.texto);

		switch (pregunta.tipo) {
			case "booleano":
				console.log("1. Si");
				console.log("2. No");
				break;

			case "opcionMultiple":
				pregunta.opciones.forEach((opcion, index) => {
					console.log(`${index + 1}. ${opcion}`);
				});
				break;

			case "texto":
				console.log("Respuesta: ____________________");
				break;

			case "rango":
				console.log("Desde: ___________________");
				console.log("Hasta: ___________________");
				break;
		}

		console.log("");
	});
}

const preguntas = [
	{
		tipo: "booleano",
		texto: "¿Es alumno regular?",
	},
	{
		tipo: "opcionMultiple",
		texto: "¿Cuál es su lenguaje preferido?",
		opciones: ["C#", "SQL", "Javascript", "Python"],
	},
	{
		tipo: "texto",
		texto: "Mencione la característica preferida del lenguaje seleccionado:",
	},
	{
		tipo: "rango",
		texto: "Lapso de tiempo en el que trabajó en su lenguaje preferido.",
	},
];

imprimirCuestionario(preguntas);
