import Rectangulo from "./rectangulo.js";
import Cuadrado from "./cuadrado.js";

const rectangulo1 = new Rectangulo(10, 4);
console.log(rectangulo1.calcularSuperficie()); // Salida: 40

const cuadrado1 = new Cuadrado(4);
console.log(cuadrado1.calcularSuperficie()); // Salida: 16

const rectangulo2 = new Cuadrado();
rectangulo2.setBase(10);
rectangulo2.setAltura(4);
console.log(rectangulo2.calcularSuperficie()); // Salida: 40
