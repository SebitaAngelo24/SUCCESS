# Materiales adicionales para el desarrollo de APIs

## Contenido de la semana

Se recopilan aquí una serie de temas asociados a la aplicación de buenas prácticas en el desarrollo de software en general y específicamente en el desarrollo de APIs.

## Lista de materiales

- [Principios SOLID](material-adicional/solid/solid.md)
- [Arquitecturas y Patrones de diseño](material-adicional/patrones/arquitecturas_y_patrones.md)
- [12 Factor](material-adicional/patrones/12-factor-app.md)

## Lista de ejemplos

- [Ejemplos: Ejemplos Solid](solid/js/)

## Autores

Soledad Romero, Rubén Romero - Cátedra de Desarrollo de Software

## License

Este trabajo está licenciado bajo una Licencia Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional. Para ver una copia de esta licencia, visita [https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es](!https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es).
