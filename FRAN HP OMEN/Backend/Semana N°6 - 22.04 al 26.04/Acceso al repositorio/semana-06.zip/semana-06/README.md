# Desarrollo de Software - Semana 6

## Contenido de la semana

Esta semana de clase nos centramos en la construcción de nuestras APIs de Backend, y más allá del análisis de arquitectura de microservicios y los principios de REST, introducimos herramientas fundamentales para la construcción este backend como son Sequelize para realizar Object Relational Mapping y Express como framework de backend.

## Lista de materiales

- [Apunte 11 - ORM con Sequelize](./apunte-11/Apunte11.md)
- [Apunte 12 - Arquitectura Backend](./apunte-12/Apunte12.md)
- [Apunte 13 - Express](./apunte-13/Apunte13.md)

## Material Adicional

- [Principios SOLID](material-adicional/solid/solid.md)
- [Arquitecturas y Patrones de diseño](material-adicional/patrones/arquitecturas_y_patrones.md)
- [12 Factor](material-adicional/patrones/12-factor-app.md)

## Clonar el presente repositorio

``` bash
cd dds_work_dir
git clone https://labsys.frc.utn.edu.ar/gitlab/desarrollo-de-software1/materiales/semana-06.git
```

## Lista de ejemplos

- [Ejercitación 1: Paso a Paso con Sequelize](apunte-11/pap_sequelize/pap_sequelize.md)
- [Ejercitación 2: API básica con Express](apunte-13/dds-express-hola-mundo)
- [Ejercitación 3: API con Express, Sequelize y SqLite](/apunte-13/pap_express_sequelize/pap_express_sequelize.md)

## Autores

Soledad Romero, Rubén Romero, Felipe Steffolani - Cátedra de Desarrollo de Software

## License

Este trabajo está licenciado bajo una Licencia Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional. Para ver una copia de esta licencia, visita [https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es](!https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es).
