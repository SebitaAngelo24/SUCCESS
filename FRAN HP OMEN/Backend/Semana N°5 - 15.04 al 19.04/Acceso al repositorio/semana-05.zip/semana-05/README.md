# Desarrollo de Software - Semana 5

## Contenido de la semana

Esta semana de clase proponemos profundizar en el funcionamiento y utilización de Nodejs y NPM y Avanzar con Javascript revisando capacidades de programación asincrónica, acceso a archivos, Maps y acceso a aplicaciones externas.

## Lista de materiales

- [Apunte 9 - Nodejs y NPM](./apunte-09/Apunte09.md)
- [Apunte 10 - Acceso a recursos externos - Programación asincrónica](./apunte-10/Apunte10.md)

## Clonar el presente repositorio

``` bash
cd dds_work_dir
git clone https://labsys.frc.utn.edu.ar/gitlab/desarrollo-de-software1/materiales/semana-05.git
```

## Lista de ejemplos

- [Ejercitacion 1: Primer Proyecto Nodejs](/apunte-09/primerProyectoNodejs)
- [Ejercitación 2: Generación de números aleatorios](/apute-09/desafio-1)
- [Ejercitación 3: Proceso de archivos CSV y JSON](/apunte-10/proceso-tbbt-csv)
- [Ejemplo paso a paso](/apunte-10/js/README.md)

## Autores

Felipe Steffolani - Cátedra de Desarrollo de Software

## License

Este trabajo está licenciado bajo una Licencia Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional. Para ver una copia de esta licencia, visita [https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es](!https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es).
