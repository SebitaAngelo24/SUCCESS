export class Entidad {
    #id;

    constructor(id) {
        this.#id = id;
    }
}

