"use strict";

// Este es el script de inicio del primer proyecto Nodejs creado a partir de npm init
console.log("\nAplicaci�n Nodejs Ejecutada correctamente... ");
console.log();

