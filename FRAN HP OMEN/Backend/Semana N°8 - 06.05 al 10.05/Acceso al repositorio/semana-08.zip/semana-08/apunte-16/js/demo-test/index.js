
export function sumar(a, b) {
	return a + b;
}

export function cuentaLetras(texto) {
	return texto.length;
}

export default sumar;
