# Desarrollo de Software - Semana 8

## Contenido de la semana

- Testing de aplicaciones Web y APIs
- Seguridad en aplicaciones Web

## Lista de materiales

- [Apunte 16 - Testing](./apunte-16/Apunte16.md)
- [Apunte 17 - Introducción a Seguridad Web](./apunte-17/Apunte17.md)
- [Apunte 18 - Autorización y Autenticación](./apunte-18/Apunte18.md)

## Clonar el presente repositorio

``` bash
cd dds_work_dir
git clone https://labsys.frc.utn.edu.ar/gitlab/desarrollo-de-software1/materiales/semana-08.git
```

## Lista de Ejemplos

- [Ejemplo de introducción a Jest](./apunte-16/js/demo-test/)
- [Ejemplo básico de testing de una API](./apunte-16/js/demo-test-api/)

## Autores

Milagros Zea Cardenas - Soledad Romero - Cátedra de Desarrollo de Software

## License

Este trabajo está licenciado bajo una Licencia Creative Commons Atribución-NoComercial-CompartirIgual 4.0 Internacional. Para ver una copia de esta licencia, visita [https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es](!https://creativecommons.org/licenses/by-nc-sa/4.0/deed.es).
